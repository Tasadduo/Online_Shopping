/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tasad
 */
public class myconnection {
 
    
    
    
    
    public static Connection connect(){
         Connection con=null;
        try {
           
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb","root","");
            Component rootPane=null;
            System.out.println("connected");
        } catch (SQLException ex) {
            Logger.getLogger(myconnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
        
   }
    
}
