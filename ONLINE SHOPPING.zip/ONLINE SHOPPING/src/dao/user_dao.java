package dao;

import connection.myconnection;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class user_dao {
  
    
    
  Connection con=myconnection.connect();
  PreparedStatement ps;
  Statement st;
  ResultSet rs;
  
  public int getMaxRow(){
      int row=0;
      try {
          st=con.createStatement();
          rs=st.executeQuery("select max(user_id) from user");
          while(rs.next()){
              row=rs.getInt(1);
          }
      } catch (SQLException ex) {
          Logger.getLogger(user_dao.class.getName()).log(Level.SEVERE, null, ex);
      }
      return row;
      
  }
  //check if email already exist
  public boolean isEmailExist(){
      
     
          
      try {
          ps=con.prepareStatement("select * from user where email=?");
          short e = 0;
          ps.setShort(1,e);
          rs=ps.executeQuery();
          if(rs.next()){
              return true;
          }
      } catch (SQLException ex) {
          Logger.getLogger(user_dao.class.getName()).log(Level.SEVERE, null, ex);
      }
      return false;
          
           
      
  }
  
  
  
  //insert data into user table
public void insert(int id , String name , String e ,String pas , String ph , String a1 , String a2 ){
    String sql="insert into user values (?,?,?,?,?,?,?)";
      try {
          ps=con.prepareStatement(sql);
          ps.setInt(1, id);
          ps.setString(2, name);
          ps.setString(3, e);
          ps.setString(4, pas);
          ps.setString(5, ph);
          ps.setString(6, a1);
          ps.setString(7,a2);
          if(ps.executeUpdate() > 0){
              JOptionPane.showMessageDialog(null, "User Added Succefully");
          }
          
      } catch (SQLException ex) {
          Logger.getLogger(user_dao.class.getName()).log(Level.SEVERE, null, ex);
      }
}
       
}
