
package online.shopping;

/**
 *
 * @author tasad
 */
public class ONLINESHOPPING {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
